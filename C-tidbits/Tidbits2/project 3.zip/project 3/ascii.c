#include <stdio.h>

int main() {
printf("   ____      _____ \n");   
printf("U |  _\"\\ u  |_ \" _| \n");
printf(" \\| |_) |/    | |   \n"); 
printf("  |  _ <     /| |\\  \n"); 
printf("  |_| \\_\\   u |_| U  \n"); 
printf("  //   \\\\_  _// \\\\_ \n");
printf(" (__)  (__)(__) (__)\n" );

return 0;
}
